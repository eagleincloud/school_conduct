from unittest import mock

from django.urls import reverse
from django.test import SimpleTestCase, TestCase, override_settings
from django.utils import timezone
from rest_framework import status
from rest_framework.test import APITestCase

from accounts.models import User
from attendance.management.commands.run_biometric_tcp_server import BiometricTCPRequestHandler
from attendance.models import Attendance, BiometricDevice
from attendance.services import (
    compute_event_fingerprint,
    extract_message_frames,
    parse_tcp_xml_payload,
    process_biometric_event,
    resolve_tcp_device,
)
from classes.models import ClassSection, MainClass, MainSection
from students.models import StudentProfile
from tenants.models import School
from teachers.models import TeacherProfile


class BiometricDeviceApiTests(APITestCase):
    def setUp(self):
        self.school = School.objects.create(name='North Campus', school_id='NORTH')
        self.other_school = School.objects.create(name='South Campus', school_id='SOUTH')
        self.admin_user = User.objects.create_user(
            username='north-admin',
            password='pass1234',
            role='admin',
            school=self.school,
            email='north@example.com',
        )
        self.superadmin_user = User.objects.create_user(
            username='root-admin',
            password='pass1234',
            role='superadmin',
            email='root@example.com',
        )

    def test_admin_creates_device_in_own_school_scope(self):
        self.client.force_authenticate(self.admin_user)

        response = self.client.post(
            reverse('biometric-device-list-create'),
            {
                'school': self.other_school.school_id,
                'name': 'Main Gate',
                'device_ip': '192.168.0.50',
                'device_port': 4370,
                'machine_number': 1,
            },
            format='json',
        )

        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(BiometricDevice.objects.count(), 1)
        self.assertEqual(BiometricDevice.objects.first().school, self.school)

    def test_superadmin_filters_devices_by_school_code(self):
        device_one = BiometricDevice.objects.create(
            school=self.school,
            name='North Lobby',
            device_ip='192.168.0.10',
        )
        BiometricDevice.objects.create(
            school=self.other_school,
            name='South Lobby',
            device_ip='192.168.0.11',
        )

        self.client.force_authenticate(self.superadmin_user)
        response = self.client.get(reverse('biometric-device-list-create'), {'school': self.school.school_id})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 1)
        self.assertEqual(response.data[0]['id'], device_one.id)


class BiometricTcpHelpersTests(SimpleTestCase):
    def test_extract_message_frames_handles_multiple_messages_and_remainder(self):
        buffer = (
            "<Message><DeviceSerialNo>A1</DeviceSerialNo></Message>"
            "<Message><DeviceSerialNo>A2</DeviceSerialNo></Message><Mess"
        )
        frames, remainder = extract_message_frames(buffer)

        self.assertEqual(len(frames), 2)
        self.assertTrue(frames[0].endswith("</Message>"))
        self.assertEqual(remainder, "<Mess")

    def test_parse_tcp_xml_payload_and_fingerprint_are_stable(self):
        raw_payload = (
            "<Message><DeviceSerialNo>T230700006</DeviceSerialNo>"
            "<Event>TimeLog</Event><UserID>2</UserID><Year>2026</Year>"
            "<Month>06</Month><Day>25</Day><Hour>16</Hour><Minute>04</Minute>"
            "<Second>22</Second></Message>"
        )
        payload = parse_tcp_xml_payload(raw_payload)

        self.assertEqual(payload['DeviceSerialNo'], 'T230700006')
        self.assertEqual(payload['Event'], 'TimeLog')
        self.assertEqual(
            compute_event_fingerprint('tcp_xml', payload),
            compute_event_fingerprint('tcp_xml', payload),
        )

    @override_settings(BIOMETRIC_TCP_ACK_MESSAGE='OK\r\n', BIOMETRIC_TCP_SOCKET_TIMEOUT=1, BIOMETRIC_TCP_MAX_PAYLOAD_BYTES=65536)
    def test_request_handler_processes_all_messages_in_same_connection(self):
        class FakeSocket:
            def __init__(self, chunks):
                self._chunks = list(chunks)
                self.sent = []
                self.timeout = None

            def settimeout(self, value):
                self.timeout = value

            def recv(self, _size):
                if self._chunks:
                    return self._chunks.pop(0)
                return b''

            def sendall(self, data):
                self.sent.append(data)

        payload = (
            "<Message><DeviceSerialNo>T230700006</DeviceSerialNo><TerminalID>4</TerminalID>"
            "<Event>TimeLog</Event><UserID>3</UserID><Year>2026</Year><Month>06</Month>"
            "<Day>29</Day><Hour>10</Hour><Minute>10</Minute><Second>04</Second></Message>"
            "<Message><DeviceSerialNo>T230700006</DeviceSerialNo><TerminalID>4</TerminalID>"
            "<Event>TimeLog</Event><UserID>4</UserID><Year>2026</Year><Month>06</Month>"
            "<Day>29</Day><Hour>10</Hour><Minute>11</Minute><Second>25</Second></Message>"
        ).encode('utf-8')
        fake_socket = FakeSocket([payload, b''])

        with mock.patch(
            'attendance.management.commands.run_biometric_tcp_server.process_biometric_event',
            return_value={'status': 'processed'},
        ) as process_event_mock:
            BiometricTCPRequestHandler(fake_socket, ('103.106.31.187', 50000), mock.Mock())

        self.assertEqual(process_event_mock.call_count, 2)
        self.assertEqual(fake_socket.sent, [b'OK\r\n', b'OK\r\n'])


class BiometricTcpDeviceResolutionTests(TestCase):
    def setUp(self):
        self.school = School.objects.create(name='North Campus', school_id='NORTH')

    def test_resolves_by_serial_first(self):
        device = BiometricDevice.objects.create(
            school=self.school,
            name='Main Gate',
            integration_mode='tcp_xml_push',
            device_serial_number='T230700006',
            terminal_id='4',
        )

        resolved = resolve_tcp_device(
            {'DeviceSerialNo': 'T230700006', 'TerminalID': '4'},
            source_ip='103.106.31.187',
        )

        self.assertEqual(resolved, device)

    def test_resolves_by_terminal_id_only_with_source_ip_allowlist(self):
        device = BiometricDevice.objects.create(
            school=self.school,
            name='Main Gate',
            integration_mode='tcp_xml_push',
            terminal_id='4',
            allowed_source_ip='103.106.31.187',
        )

        resolved = resolve_tcp_device(
            {'DeviceSerialNo': 'WRONG-SERIAL', 'TerminalID': '4'},
            source_ip='103.106.31.187',
        )

        self.assertEqual(resolved, device)

    def test_terminal_id_fallback_requires_matching_source_ip(self):
        BiometricDevice.objects.create(
            school=self.school,
            name='Main Gate',
            integration_mode='tcp_xml_push',
            terminal_id='4',
            allowed_source_ip='103.106.31.187',
        )

        with self.assertRaises(LookupError):
            resolve_tcp_device(
                {'DeviceSerialNo': 'WRONG-SERIAL', 'TerminalID': '4'},
                source_ip='103.187.100.70',
            )


class TeacherManualAttendanceOverrideTests(APITestCase):
    def setUp(self):
        self.school = School.objects.create(name='North Campus', school_id='NORTH')
        self.teacher_user = User.objects.create_user(
            username='class-teacher',
            password='pass1234',
            role='teacher',
            school=self.school,
            email='teacher@example.com',
        )
        self.teacher_profile = TeacherProfile.objects.create(
            user=self.teacher_user,
            school=self.school,
            employee_id='T-001',
            role='Class Teacher',
        )
        self.main_class = MainClass.objects.create(school=self.school, name='10')
        self.main_section = MainSection.objects.create(school=self.school, name='A')
        self.class_section = ClassSection.objects.create(
            school=self.school,
            class_ref=self.main_class,
            section_ref=self.main_section,
            class_teacher=self.teacher_profile,
        )
        self.student_user = User.objects.create_user(
            username='student-one',
            password='pass1234',
            role='student',
            school=self.school,
            email='student@example.com',
        )
        self.student_profile = StudentProfile.objects.create(
            user=self.student_user,
            school=self.school,
            admission_number='ADM-001',
            roll_number='1',
            rfid_code='RFID-001',
            class_section=self.class_section,
        )
        self.client.force_authenticate(self.teacher_user)

    def test_manual_mark_endpoint_allows_overriding_biometric_attendance_row(self):
        today = timezone.localdate()
        attendance = Attendance.objects.create(
            student=self.student_profile,
            class_section=self.class_section,
            date=today,
            status='present',
            verification_status='approved',
            marked_via='rfid',
        )

        response = self.client.post(
            reverse('mark-attendance'),
            {
                'student': self.student_profile.id,
                'date': attendance.date.isoformat(),
                'status': 'absent',
            },
            format='json',
        )

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        attendance.refresh_from_db()
        self.assertEqual(attendance.marked_via, 'manual')
        self.assertEqual(attendance.status, 'absent')
        self.assertEqual(attendance.verification_status, 'rejected')

    def test_bulk_save_allows_overriding_biometric_attendance_rows(self):
        today = timezone.localdate()
        Attendance.objects.create(
            student=self.student_profile,
            class_section=self.class_section,
            date=today,
            status='present',
            verification_status='approved',
            marked_via='rfid',
        )

        response = self.client.post(
            reverse('teacher-attendance-bulk-save'),
            {
                'class_section_id': self.class_section.id,
                'date': today.isoformat(),
                'rows': [
                    {
                        'student_id': self.student_profile.id,
                        'status': 'absent',
                    }
                ],
            },
            format='json',
        )

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['saved'], 1)

        attendance = Attendance.objects.get(student=self.student_profile, date=today)
        self.assertEqual(attendance.marked_via, 'manual')
        self.assertEqual(attendance.status, 'absent')
        self.assertEqual(attendance.verification_status, 'rejected')


class BiometricPunchApprovalTests(TestCase):
    def setUp(self):
        self.school = School.objects.create(name='North Campus', school_id='NORTH')
        self.teacher_user = User.objects.create_user(
            username='class-teacher-two',
            password='pass1234',
            role='teacher',
            school=self.school,
            email='teacher2@example.com',
        )
        self.teacher_profile = TeacherProfile.objects.create(
            user=self.teacher_user,
            school=self.school,
            employee_id='T-002',
            role='Class Teacher',
        )
        self.main_class = MainClass.objects.create(school=self.school, name='9')
        self.main_section = MainSection.objects.create(school=self.school, name='B')
        self.class_section = ClassSection.objects.create(
            school=self.school,
            class_ref=self.main_class,
            section_ref=self.main_section,
            class_teacher=self.teacher_profile,
        )
        self.student_user = User.objects.create_user(
            username='student-two',
            password='pass1234',
            role='student',
            school=self.school,
            email='student2@example.com',
        )
        self.student_profile = StudentProfile.objects.create(
            user=self.student_user,
            school=self.school,
            admission_number='ADM-002',
            roll_number='2',
            rfid_code='3',
            class_section=self.class_section,
        )
        self.device = BiometricDevice.objects.create(
            school=self.school,
            name='Main Gate',
            integration_mode='tcp_xml_push',
            device_serial_number='T230700006',
            terminal_id='4',
            allowed_source_ip='103.106.31.187',
        )

    def test_tcp_biometric_punch_marks_student_present_immediately(self):
        now = timezone.now()
        payload = {
            'DeviceSerialNo': 'T230700006',
            'TerminalID': '4',
            'Event': 'TimeLog',
            'UserID': '3',
            'Year': str(now.year),
            'Month': str(now.month),
            'Day': str(now.day),
            'Hour': str(now.hour),
            'Minute': str(now.minute),
            'Second': str(now.second),
        }

        result = process_biometric_event(
            protocol='tcp_xml',
            payload=payload,
            raw_payload='<Message />',
            source_ip='103.106.31.187',
        )

        self.assertTrue(result['ok'])
        self.assertEqual(result['status'], 'processed')

        attendance = Attendance.objects.get(student=self.student_profile, date=timezone.localdate())
        self.assertEqual(attendance.status, 'present')
        self.assertEqual(attendance.verification_status, 'approved')
        self.assertEqual(attendance.marked_via, 'rfid')
