import logging
import socketserver

from django.conf import settings
from django.core.management.base import BaseCommand

from attendance.services import extract_message_frames, parse_tcp_xml_payload, process_biometric_event

logger = logging.getLogger(__name__)


class BiometricTCPRequestHandler(socketserver.BaseRequestHandler):
    def handle(self):
        self.request.settimeout(settings.BIOMETRIC_TCP_SOCKET_TIMEOUT)
        max_payload_bytes = settings.BIOMETRIC_TCP_MAX_PAYLOAD_BYTES
        ack_bytes = settings.BIOMETRIC_TCP_ACK_MESSAGE.encode("utf-8")
        source_ip = self.client_address[0] if self.client_address else None
        buffer = ""

        while True:
            try:
                chunk = self.request.recv(4096)
            except TimeoutError:
                break
            except OSError as exc:
                logger.warning("Biometric TCP socket error from %s: %s", source_ip, exc)
                break

            if not chunk:
                break

            buffer += chunk.decode("utf-8", errors="ignore")
            if len(buffer.encode("utf-8")) > max_payload_bytes:
                logger.warning("Biometric payload exceeded max size from %s; truncating connection.", source_ip)
                break

            frames, buffer = extract_message_frames(buffer)
            for frame in frames:
                try:
                    payload = parse_tcp_xml_payload(frame)
                    result = process_biometric_event(
                        protocol='tcp_xml',
                        payload=payload,
                        raw_payload=frame,
                        source_ip=source_ip,
                    )
                    logger.info(
                        "Processed biometric TCP event serial=%s event=%s status=%s",
                        payload.get('DeviceSerialNo', ''),
                        payload.get('Event', ''),
                        result.get('status', 'unknown'),
                    )
                    # Keep the socket open long enough to drain all queued punches
                    # from the same device connection. Some devices batch multiple
                    # TimeLog messages and only flush them after seeing an ACK for
                    # each frame.
                    self.request.sendall(ack_bytes)
                except Exception as exc:
                    logger.exception("Failed to process biometric TCP payload from %s: %s", source_ip, exc)


class ThreadedTCPServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
    allow_reuse_address = True
    daemon_threads = True


class Command(BaseCommand):
    help = "Run the production TCP XML server for biometric devices that push attendance over the internet."

    def add_arguments(self, parser):
        parser.add_argument('--host', default=settings.BIOMETRIC_TCP_HOST)
        parser.add_argument('--port', type=int, default=settings.BIOMETRIC_TCP_PORT)

    def handle(self, *args, **options):
        host = options['host']
        port = options['port']

        with ThreadedTCPServer((host, port), BiometricTCPRequestHandler) as server:
            self.stdout.write(self.style.SUCCESS(f"Biometric TCP XML server listening on {host}:{port}"))
            try:
                server.serve_forever()
            except KeyboardInterrupt:
                self.stdout.write(self.style.WARNING("Biometric TCP XML server stopped by user."))
