import hashlib
import logging
from datetime import datetime as datetime_type
from xml.etree import ElementTree

from django.db import models, transaction
from django.utils import timezone

from students.models import StudentProfile
from teachers.models import TeacherProfile

from .models import Attendance, BiometricDevice, BiometricEventLog, TeacherAttendance

logger = logging.getLogger(__name__)


class AttendanceService:
    @staticmethod
    def mark_attendance(student_id, date, status, marked_by_id):
        attendance, created = Attendance.objects.update_or_create(
            student_id=student_id,
            date=date,
            defaults={'status': status, 'marked_by_id': marked_by_id},
        )
        return attendance, created


def extract_message_frames(buffer: str):
    frames = []
    remainder = buffer

    while True:
        start = remainder.find("<Message")
        if start == -1:
            return frames, remainder[-2048:]

        end = remainder.find("</Message>", start)
        if end == -1:
            return frames, remainder[start:]

        end += len("</Message>")
        frames.append(remainder[start:end])
        remainder = remainder[end:]


def parse_tcp_xml_payload(raw_payload: str):
    root = ElementTree.fromstring(raw_payload.strip())
    payload = {}
    for child in root:
        payload[child.tag] = (child.text or "").strip()
    return payload


def _normalize_target_type(value):
    normalized = (value or "").strip().lower()
    if normalized in {"student", "teacher"}:
        return normalized
    return ""


def _parse_punch_time(payload):
    punch_time_raw = payload.get('punch_time') or payload.get('PunchTime')
    if punch_time_raw:
        try:
            punch_dt = datetime_type.strptime(str(punch_time_raw), "%Y-%m-%d %H:%M:%S")
            if timezone.is_naive(punch_dt):
                punch_dt = timezone.make_aware(punch_dt, timezone.get_current_timezone())
            return punch_dt
        except Exception:
            pass

    year = payload.get('Year')
    month = payload.get('Month')
    day = payload.get('Day')
    hour = payload.get('Hour', '0')
    minute = payload.get('Minute', '0')
    second = payload.get('Second', '0')
    if year and month and day:
        try:
            punch_dt = datetime_type(
                int(year),
                int(month),
                int(day),
                int(hour or 0),
                int(minute or 0),
                int(second or 0),
            )
            return timezone.make_aware(punch_dt, timezone.get_current_timezone())
        except Exception:
            pass

    return timezone.now()


def compute_event_fingerprint(protocol: str, payload: dict):
    base = "|".join(
        [
            protocol,
            payload.get('DeviceSerialNo', '') or payload.get('device_serial_number', ''),
            payload.get('Event', '') or payload.get('event', ''),
            payload.get('TransID', '') or payload.get('trans_id', ''),
            payload.get('UserID', '') or payload.get('rfid_code', ''),
            payload.get('punch_time', ''),
            payload.get('Year', ''),
            payload.get('Month', ''),
            payload.get('Day', ''),
            payload.get('Hour', ''),
            payload.get('Minute', ''),
            payload.get('Second', ''),
        ]
    )
    return hashlib.sha256(base.encode("utf-8")).hexdigest()


def resolve_tcp_device(payload: dict, source_ip: str | None = None):
    serial = (payload.get('DeviceSerialNo') or "").strip()
    terminal_id = (payload.get('TerminalID') or "").strip()

    device = None
    if serial:
        device = (
            BiometricDevice.objects.select_related('school')
            .filter(
                integration_mode='tcp_xml_push',
                device_serial_number__iexact=serial,
                is_active=True,
            )
            .first()
        )

    # Fallback for devices whose reported serial is unreliable. TerminalID is not
    # globally unique, so require a source-IP allowlist before trusting it.
    if not device and terminal_id and source_ip:
        device = (
            BiometricDevice.objects.select_related('school')
            .filter(
                integration_mode='tcp_xml_push',
                terminal_id=terminal_id,
                allowed_source_ip=source_ip,
                is_active=True,
            )
            .first()
        )

    if not device:
        identity = f"serial {serial}" if serial else "missing serial"
        if terminal_id:
            identity = f"{identity}, terminal {terminal_id}"
        raise LookupError(f"No active TCP XML biometric device is registered for {identity}.")

    if device.allowed_source_ip and source_ip and device.allowed_source_ip != source_ip:
        raise PermissionError(
            f"Source IP {source_ip} is not allowed for device serial {serial}. Expected {device.allowed_source_ip}."
        )

    if terminal_id and device.terminal_id and str(device.terminal_id).strip() != terminal_id:
        raise PermissionError(
            f"Terminal ID mismatch for serial {serial}. Received {terminal_id}, expected {device.terminal_id}."
        )

    return device


def resolve_http_device(payload: dict, api_key: str | None):
    school_id = payload.get('school_id')
    if not school_id:
        raise ValueError("school_id is required.")

    device = (
        BiometricDevice.objects.select_related('school')
        .filter(
            school__school_id=school_id,
            device_secret_key=api_key,
            is_active=True,
        )
        .first()
    )
    if not device:
        raise PermissionError("Invalid device token or school mismatch.")
    return device


def _resolve_student(identifier: str, school_id: str):
    if not identifier:
        return None
    return (
        StudentProfile.objects.select_related('class_section', 'user', 'school')
        .filter(school__school_id=school_id)
        .filter(
            models.Q(rfid_code=identifier)
            | models.Q(admission_number=identifier)
            | models.Q(roll_number=identifier)
            | models.Q(user__username=identifier)
        )
        .first()
    )


def _resolve_teacher(identifier: str, school_id: str):
    if not identifier:
        return None
    return (
        TeacherProfile.objects.select_related('user', 'school')
        .filter(school__school_id=school_id)
        .filter(
            models.Q(rfid_code=identifier)
            | models.Q(employee_id=identifier)
            | models.Q(user__username=identifier)
        )
        .first()
    )


def _process_teacher_attendance(teacher, punch_dt):
    attendance, created = TeacherAttendance.objects.get_or_create(
        teacher=teacher,
        date=punch_dt.date(),
        defaults={
            'status': 'present',
            'marked_via': 'rfid',
            'punch_in_time': punch_dt,
        },
    )
    if not created:
        if not attendance.punch_out_time or attendance.punch_out_time < punch_dt:
            attendance.punch_out_time = punch_dt
            attendance.save(update_fields=['punch_out_time'])
        message = 'Punch-out recorded'
    else:
        message = 'Punch-in recorded successfully'
    return attendance, created, message


def _process_student_attendance(student, punch_dt):
    attendance, created = Attendance.objects.select_related('student').get_or_create(
        student=student,
        date=punch_dt.date(),
        defaults={
            'status': 'present',
            'verification_status': 'approved',
            'marked_via': 'rfid',
            'punch_time': punch_dt,
            'class_section': student.class_section,
        },
    )

    if not created and attendance.verification_status == 'approved' and attendance.status in ('present', 'late'):
        if not attendance.punch_time or attendance.punch_time < punch_dt:
            attendance.punch_time = punch_dt
            attendance.save(update_fields=['punch_time'])
        message = 'Punch received: attendance already approved'
        return attendance, created, message

    if not created:
        if attendance.status == 'absent' or attendance.verification_status == 'rejected':
            attendance.status = 'present'
            attendance.verification_status = 'approved'
            attendance.marked_via = 'rfid'
            attendance.punch_time = punch_dt
            attendance.class_section = student.class_section
            attendance.marked_by = None
            attendance.verified_by = None
            attendance.verified_at = timezone.now()
            attendance.save()
            message = 'Punch processed and attendance marked present'
        else:
            attendance.status = 'present'
            attendance.verification_status = 'approved'
            attendance.marked_via = 'rfid'
            attendance.punch_time = punch_dt
            attendance.class_section = student.class_section
            attendance.marked_by = None
            attendance.verified_by = None
            attendance.verified_at = timezone.now()
            attendance.save()
            message = 'Punch processed successfully'
    else:
        attendance.status = 'present'
        attendance.verification_status = 'approved'
        attendance.marked_via = 'rfid'
        attendance.punch_time = punch_dt
        attendance.class_section = student.class_section
        attendance.marked_by = None
        attendance.verified_by = None
        attendance.verified_at = timezone.now()
        attendance.save()
        message = 'Punch processed successfully'

    return attendance, created, message


def _base_event_log_kwargs(device, protocol, source_ip, payload, raw_payload, punch_dt, fingerprint):
    return {
        'device': device,
        'school': device.school if device else None,
        'protocol': protocol,
        'status': 'received',
        'event_fingerprint': fingerprint,
        'source_ip': source_ip,
        'device_serial_number': (payload.get('DeviceSerialNo') or payload.get('device_serial_number') or '').strip(),
        'terminal_id': (payload.get('TerminalID') or payload.get('terminal_id') or '').strip(),
        'trans_id': (payload.get('TransID') or payload.get('trans_id') or '').strip(),
        'event_type': (payload.get('Event') or payload.get('event') or '').strip(),
        'user_identifier': str(payload.get('UserID') or payload.get('rfid_code') or '').strip(),
        'attend_stat': (payload.get('AttendStat') or '').strip(),
        'verify_mode': (payload.get('VerifMode') or '').strip(),
        'punch_time': punch_dt,
        'raw_payload': raw_payload,
        'normalized_payload': payload,
    }


@transaction.atomic
def process_biometric_event(
    *,
    protocol: str,
    payload: dict,
    raw_payload: str = "",
    source_ip: str | None = None,
    api_key: str | None = None,
):
    payload = dict(payload)
    if protocol == 'http' and payload.get('rfid_code') and not (payload.get('Event') or payload.get('event')):
        payload['Event'] = 'TimeLog'

    fingerprint = compute_event_fingerprint(protocol, payload)
    existing = BiometricEventLog.objects.filter(event_fingerprint=fingerprint).first()
    if existing:
        try:
            if protocol == 'tcp_xml':
                device = resolve_tcp_device(payload, source_ip=source_ip)
            elif protocol == 'http':
                device = resolve_http_device(payload, api_key=api_key)
            else:
                device = None
        except Exception:
            device = None

        if device:
            event_type = (payload.get('Event') or payload.get('event') or existing.event_type or 'Punch').strip()
            device.last_seen_at = timezone.now()
            device.last_event_type = event_type[:50]
            device.last_test_status = 'online'
            device.save(update_fields=['last_seen_at', 'last_event_type', 'last_test_status'])

            update_fields = []
            if existing.device_id != device.id:
                existing.device = device
                existing.school = device.school
                update_fields.extend(['device', 'school'])
            if update_fields:
                existing.save(update_fields=update_fields)

        return {
            'ok': True,
            'status': 'duplicate',
            'message': 'Duplicate biometric event ignored.',
            'event_log_id': existing.id,
        }

    punch_dt = _parse_punch_time(payload)
    device = None

    try:
        if protocol == 'tcp_xml':
            device = resolve_tcp_device(payload, source_ip=source_ip)
        elif protocol == 'http':
            device = resolve_http_device(payload, api_key=api_key)
        else:
            raise ValueError(f"Unsupported protocol {protocol}.")
    except Exception as exc:
        event_log_kwargs = _base_event_log_kwargs(
            None,
            protocol,
            source_ip,
            payload,
            raw_payload,
            punch_dt,
            fingerprint,
        )
        event_log_kwargs.update(
            {
                'status': 'unauthorized',
                'error_message': str(exc)[:255],
                'processed_at': timezone.now(),
            }
        )
        event_log = BiometricEventLog.objects.create(
            **event_log_kwargs,
        )
        logger.warning("Rejected biometric event: %s", exc)
        return {
            'ok': False,
            'status': 'unauthorized',
            'message': str(exc),
            'event_log_id': event_log.id,
        }

    event_log = BiometricEventLog.objects.create(
        **_base_event_log_kwargs(device, protocol, source_ip, payload, raw_payload, punch_dt, fingerprint),
    )

    event_type = (payload.get('Event') or '').strip() or 'Punch'
    device.last_seen_at = timezone.now()
    device.last_event_type = event_type[:50]
    device.last_test_status = 'online'
    device.last_test_message = f"Received {event_type} over {protocol}."
    update_fields = ['last_seen_at', 'last_event_type', 'last_test_status', 'last_test_message']

    user_identifier = str(payload.get('UserID') or payload.get('rfid_code') or '').strip()
    target_type = _normalize_target_type(payload.get('target_type'))

    if event_type.lower() != 'timelog':
        device.save(update_fields=update_fields)
        event_log.status = 'ignored'
        event_log.processed_at = timezone.now()
        event_log.save(update_fields=['status', 'processed_at'])
        return {
            'ok': True,
            'status': 'ignored',
            'message': f'Ignored non-attendance event {event_type}.',
            'event_log_id': event_log.id,
        }

    if not user_identifier:
        event_log.status = 'failed'
        event_log.error_message = 'User identifier missing from biometric payload.'
        event_log.processed_at = timezone.now()
        event_log.save(update_fields=['status', 'error_message', 'processed_at'])
        return {
            'ok': False,
            'status': 'failed',
            'message': event_log.error_message,
            'event_log_id': event_log.id,
        }

    school_id = device.school.school_id
    student = None
    teacher = None

    if not target_type:
        student = _resolve_student(user_identifier, school_id)
        if student:
            target_type = 'student'
        else:
            teacher = _resolve_teacher(user_identifier, school_id)
            if teacher:
                target_type = 'teacher'
    elif target_type == 'student':
        student = _resolve_student(user_identifier, school_id)
    elif target_type == 'teacher':
        teacher = _resolve_teacher(user_identifier, school_id)

    if target_type == 'student' and not student:
        event_log.status = 'unmatched'
        event_log.error_message = f'Student identifier {user_identifier} was not found for school {school_id}.'
        event_log.processed_at = timezone.now()
        event_log.save(update_fields=['status', 'error_message', 'processed_at'])
        return {
            'ok': False,
            'status': 'unmatched',
            'message': event_log.error_message,
            'event_log_id': event_log.id,
        }

    if target_type == 'teacher' and not teacher:
        event_log.status = 'unmatched'
        event_log.error_message = f'Teacher identifier {user_identifier} was not found for school {school_id}.'
        event_log.processed_at = timezone.now()
        event_log.save(update_fields=['status', 'error_message', 'processed_at'])
        return {
            'ok': False,
            'status': 'unmatched',
            'message': event_log.error_message,
            'event_log_id': event_log.id,
        }

    if not target_type:
        event_log.status = 'unmatched'
        event_log.error_message = f'Identifier {user_identifier} did not match any student or teacher in school {school_id}.'
        event_log.processed_at = timezone.now()
        event_log.save(update_fields=['status', 'error_message', 'processed_at'])
        return {
            'ok': False,
            'status': 'unmatched',
            'message': event_log.error_message,
            'event_log_id': event_log.id,
        }

    if target_type == 'teacher':
        teacher_attendance, created, message = _process_teacher_attendance(teacher, punch_dt)
        device.last_punch_at = punch_dt
        update_fields.append('last_punch_at')
        device.save(update_fields=update_fields)
        event_log.status = 'processed'
        event_log.teacher_attendance = teacher_attendance
        event_log.processed_at = timezone.now()
        event_log.save(update_fields=['status', 'teacher_attendance', 'processed_at'])
        return {
            'ok': True,
            'status': 'processed',
            'message': message,
            'target_type': 'teacher',
            'teacher_name': teacher.user.name or teacher.user.username,
            'school_name': teacher.school.name if teacher.school else '',
            'punch_in_time': teacher_attendance.punch_in_time.isoformat() if teacher_attendance.punch_in_time else None,
            'punch_out_time': teacher_attendance.punch_out_time.isoformat() if teacher_attendance.punch_out_time else None,
            'event_log_id': event_log.id,
        }

    attendance, created, message = _process_student_attendance(student, punch_dt)
    device.last_punch_at = punch_dt
    update_fields.append('last_punch_at')
    device.save(update_fields=update_fields)
    event_log.status = 'processed'
    event_log.attendance = attendance
    event_log.processed_at = timezone.now()
    event_log.save(update_fields=['status', 'attendance', 'processed_at'])
    return {
        'ok': True,
        'status': 'processed',
        'message': message,
        'target_type': 'student',
        'student_name': student.user.name or student.user.username,
        'school_name': student.school.name if student.school else '',
        'punch_time': attendance.punch_time.isoformat() if attendance.punch_time else punch_dt.isoformat(),
        'event_log_id': event_log.id,
    }
